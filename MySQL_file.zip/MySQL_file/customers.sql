SELECT * FROM sales.customers;

SELECT count(*) FROM sales.customers; # Get count of the Customers