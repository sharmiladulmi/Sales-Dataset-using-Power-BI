SELECT * FROM sales.transactions;

SELECT count(*) FROM sales.transactions; # Get the count of the transactions

SELECT * FROM sales.transactions limit 5; # Select the first five records

SELECT * FROM sales.transactions where market_code = 'Mark001'; # Select the tansactions in Chennai ("Mark001"= Chennai)

SELECT * FROM sales.transactions where currency='USD'; # Select the USD Currency records

SELECT * FROM sales.transactions where sales_amount<=0; # Select the records which the sales amount is less than to zero

SELECT distinct(transactions.currency) from transactions; # Select the currency types

SELECT count(*) from transactions where transactions.currency='INR\r'; # Get the count of duplicate values with INR\r

SELECT count(*) from transactions where transactions.currency='INR'; # Get the count of duplicate values with INR

SELECT * from transactions where transactions.currency= 'USD\r' or transactions.currency='USD';